<?php

// config/database.php
class DatabaseConfig {
    const HOST = 'localhost';
    const DB_NAME = 'spacenet_saas';
    const USERNAME = 'your_db_username';
    const PASSWORD = 'your_db_password';
    const CHARSET = 'utf8mb4';
}
